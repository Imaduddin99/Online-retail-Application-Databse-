const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 3000;

// MySQL Connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'finalproject'
});

db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log('Connected to MySQL database');
});

// Middleware
app.use(bodyParser.json());

// Routes
// Add data
app.post('/add', (req, res) => {
  const { data } = req.body;
  const sql = 'INSERT product (product_id, name , price) VALUES (?)';
  db.query(sql, [data], (err, result) => {
    if (err) throw err;
    console.log('Data added successfully');
    res.send('Data added successfully');
  });
});

// Delete data
app.delete('/delete', (req, res) => {
  const { delete_id } = req.body;
  const sql = 'DELETE FROM product WHERE product_id = ?';
  db.query(sql, [delete_id], (err, result) => {
    if (err) throw err;
    console.log('Data deleted successfully');
    res.send('Data deleted successfully');
  });
});

// Modify data
app.put('/update', (req, res) => {
  const {modify_id, new_name, new_price} = req.body;
  const sql = 'UPDATE product SET name = ?, price = ? WHERE product_id = ?';
  db.query(sql, [new_name,new_price,modify_id], (err, result) => {
    if (err) throw err;
    console.log('Data updated successfully');
    res.send('Data updated successfully');
  });
});

// Search data
app.get('/search', (req, res) => {
  const { search } = req.query;
  const sql = 'SELECT * FROM products WHERE name LIKE ?'; // Modify query as needed
  db.query(sql, [`%${search}%`], (err, results) => {
    if (err) {
      console.error('Error searching data:', err);
      res.status(500).send('Internal Server Error');
      return;
    }
    res.json(results);
  });
});
  


// Start server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
