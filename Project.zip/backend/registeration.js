const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const path = require('path');

const app = express();

app.use(express.static(path.join(__dirname,'public')));

app.listen(3000, ()=>{
    console.log("App listening on port 3000");

})



